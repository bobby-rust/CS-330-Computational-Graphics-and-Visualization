///////////////////////////////////////////////////////////////////////////////
// shadermanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
	lightPosition = glm::vec3(1.0f, 30.0f, 0.0f);
	lightPosition2 = glm::vec3(30.0f, 10.0f, 10.0f);

	// initialize the texture collection
	for (int i = 0; i < 16; i++)
	{
		m_textureIDs[i].tag = "/0";
		m_textureIDs[i].ID = -1;
	}
	m_loadedTextures = 0;
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/

void SceneManager::DefineObjectMaterials()
{
	// Metal
	OBJECT_MATERIAL metalMaterial;
	metalMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
	metalMaterial.ambientStrength = 0.3f;
	metalMaterial.diffuseColor = glm::vec3(0.2f, 0.2f, 0.2f);
	metalMaterial.specularColor = glm::vec3(0.5f, 0.5f, 0.5f);
	metalMaterial.shininess = 22.0;
	metalMaterial.tag = "metal";

	m_objectMaterials.push_back(metalMaterial);

	// Wood
	OBJECT_MATERIAL woodMaterial;
	woodMaterial.ambientColor = glm::vec3(0.1f, 0.1f, 0.1f);
	woodMaterial.ambientStrength = 0.3f;
	woodMaterial.diffuseColor = glm::vec3(0.3f, 0.3f, 0.3f);
	woodMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);
	woodMaterial.shininess = 0.3;
	woodMaterial.tag = "wood";

	m_objectMaterials.push_back(woodMaterial);

	// Glass
	OBJECT_MATERIAL glassMaterial;
	glassMaterial.ambientColor = glm::vec3(0.4f, 0.4f, 0.4f);
	glassMaterial.ambientStrength = 0.3f;
	glassMaterial.diffuseColor = glm::vec3(0.3f, 0.3f, 0.3f);
	glassMaterial.specularColor = glm::vec3(0.6f, 0.6f, 0.6f);
	glassMaterial.shininess = 85.0;
	glassMaterial.tag = "glass";

	m_objectMaterials.push_back(glassMaterial);

	// Brick
	OBJECT_MATERIAL brickMaterial;
	brickMaterial.ambientColor = glm::vec3(0.3f, 0.2f, 0.2f);
	brickMaterial.ambientStrength = 0.3f;
	brickMaterial.diffuseColor = glm::vec3(0.6f, 0.3f, 0.3f);
	brickMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f); // Lower specular color to reduce reflection
	brickMaterial.shininess = 10.0f;                           // Reduce shininess for a more matte look
	brickMaterial.tag = "brick";

	m_objectMaterials.push_back(brickMaterial);

	// Plastic
	OBJECT_MATERIAL plasticMaterial;
	plasticMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
	plasticMaterial.ambientStrength = 0.3f;
	plasticMaterial.diffuseColor = glm::vec3(0.5f, 0.5f, 0.5f);
	plasticMaterial.specularColor = glm::vec3(0.6f, 0.6f, 0.6f);
	plasticMaterial.shininess = 50.0f;
	plasticMaterial.tag = "plastic";

	m_objectMaterials.push_back(plasticMaterial);
}

void SceneManager::SetupSceneLights()
{
	// Enable custom lighting, disable OpenGL default lighting
	m_pShaderManager->setBoolValue(g_UseLightingName, true);

	// Light source 1
	m_pShaderManager->setVec3Value("lightSources[0].position", lightPosition[0], lightPosition[1], lightPosition[2]);
	m_pShaderManager->setVec3Value("lightSources[0].ambientColor", 0.1f, 0.1f, 0.1f);
	m_pShaderManager->setVec3Value("lightSources[0].diffuseColor", 0.1f, 0.1f, 0.1f);
	m_pShaderManager->setVec3Value("lightSources[0].specularColor", 0.1f, 0.1f, 0.1f);
	m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 10.0f);
	m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 0.3f);

	// Light source 2
	m_pShaderManager->setVec3Value("lightSources[1].position", lightPosition2[0], lightPosition2[1], lightPosition2[2]);
	m_pShaderManager->setVec3Value("lightSources[1].ambientColor", 0.1f, 0.1f, 0.1f);
	m_pShaderManager->setVec3Value("lightSources[1].diffuseColor", 0.1f, 0.1f, 0.1f);
	m_pShaderManager->setVec3Value("lightSources[1].specularColor", 0.1f, 0.1f, 0.1f);
	m_pShaderManager->setFloatValue("lightSources[1].focalStrength", 20.0f);
	m_pShaderManager->setFloatValue("lightSources[1].specularIntensity", 0.3f);
}


void SceneManager::LoadSceneTextures()
{
	bool bReturn = false;
	
	bReturn = CreateGLTexture("../../Utilities/textures/spaghetti.png", "spaghetti");
	bReturn = CreateGLTexture("../../Utilities/textures/lime-green-plastic.jpg", "green-plastic");
	bReturn = CreateGLTexture("../../Utilities/textures/echoboard-koala-bear.jpg", "echoboard");
	bReturn = CreateGLTexture("../../Utilities/textures/very-dirty-tiles.jpg", "tiles");
	bReturn = CreateGLTexture("../../Utilities/textures/stainless.jpg", "stainless");
	bReturn = CreateGLTexture("../../Utilities/textures/flagstone-rubble.jpg", "rubble");
	bReturn = CreateGLTexture("../../Utilities/textures/oak.jpg", "oak");
	bReturn = CreateGLTexture("../../Utilities/textures/brick.jpg", "brick");
	bReturn = CreateGLTexture("../../Utilities/textures/concrete.jpg", "concrete");
	bReturn = CreateGLTexture("../../Utilities/textures/ceiling-tile.jpg", "ceiling-tile");
	bReturn = CreateGLTexture("../../Utilities/textures/bottle-cap.jpg", "bottle-cap");
	bReturn = CreateGLTexture("../../Utilities/textures/red-glass.jpg", "red-glass");

	BindGLTextures();
}

/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene
	
	LoadSceneTextures();
	DefineObjectMaterials();
	SetupSceneLights();

	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadSphereMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadBoxMesh();
}

void SceneManager::RenderLightGizmo()
{
	auto scaleXYZ = glm::vec3(0.5f, 0.5f, 0.5f);
	auto XrotationDegrees = 0.0f;
	auto YrotationDegrees = 0.0f;
	auto ZrotationDegrees = 0.0f;
	auto positionXYZ = glm::vec3(lightPosition[0], lightPosition[1] + 2.0f, lightPosition[2]);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
	SetShaderMaterial("plastic");
	m_basicMeshes->DrawSphereMesh();
	positionXYZ = glm::vec3(lightPosition2[0], lightPosition2[1] + 2.0f, lightPosition2[2]);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	m_basicMeshes->DrawSphereMesh();
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/

	// Render the world borders if constrained world flag is true, press c to toggle
	if (m_pShaderManager->bConstrainWorld) RenderWorldBorders();
	if (m_pShaderManager->bShowLightGizmo) RenderLightGizmo(); // For debugging light positions
	RenderTable();
	RenderCandle();
	RenderWaxMeltWarmer();
	RenderPingPongBall();
	RenderChickenBroth();
	RenderPastaBox();
	RenderMakeup();
}

void SceneManager::RenderWaxMeltWarmer()
{
	/************************ Top bowl of the candle **********************************/
	// save color values for candle as it needs to be applied to 3 different meshes
	float candleRed = 39.0f / 255;
	float candleGreen = 44.0f / 255;
	float candleBlue = 58.0f / 255;

	auto scaleXYZ = glm::vec3(1.0f, 1.0f, 1.0f);
	auto XrotationDegrees = 180.0f;
	auto YrotationDegrees = 0.0f;
	auto ZrotationDegrees = 0.0f;
	auto positionXYZ = glm::vec3(0.0f, 3.2f, 0.0f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderColor(candleRed, candleGreen, candleBlue, 1);
	SetShaderMaterial("metal");
	m_basicMeshes->DrawHalfSphereMesh();
	
	/************************ Candle upside down bowl on top of the cylinder *****************************/
	scaleXYZ = glm::vec3(1.0f, 1.0f, 1.0f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 22.5f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(0.0f, 1.5f, 0.0f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderColor(candleRed, candleGreen, candleBlue, 1);
	SetShaderMaterial("metal");
	m_basicMeshes->DrawHalfSphereMesh();

	/************************ Candle Base Cylinder *****************************/
	scaleXYZ = glm::vec3(1.0f, 1.5f, 1.0f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(0.0f, 0.001f, 0.0f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderColor(candleRed, candleGreen, candleBlue, 1);
	SetShaderMaterial("metal");
	m_basicMeshes->DrawCylinderMesh();
}

void SceneManager::RenderCandle()
{
	/*********************** Red candle base cylinder **********************/
	auto scaleXYZ = glm::vec3(1.5, 1.0f, 1.5);
	auto XrotationDegrees = 0.0f;
	auto YrotationDegrees = 90.0f;
	auto ZrotationDegrees = 0.0f;
	auto positionXYZ = glm::vec3(-2.3f, 0.001f, 2.0f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderColor(82 / 255.0f, 17 / 255.0f, 15 / 255.0f, 1.0f);
	SetShaderMaterial("glass");
	m_basicMeshes->DrawCylinderMesh();

	/********************** Red candle upside down bowl on top of the cylinder ***************/
	scaleXYZ = glm::vec3(1.5, 0.8f, 1.5);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-2.3f, 1.002f, 2.0f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderColor(82 / 255.0f, 17 / 255.0f, 15 / 255.0f, 1.0f);
	SetShaderMaterial("glass");
	m_basicMeshes->DrawHalfSphereMesh();


	/************************* Red candle neck cyliner *******************************/
	scaleXYZ = glm::vec3(1.0, 0.3f, 1.0);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-2.3f, 1.502f, 2.0f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderColor(82 / 255.0f, 17 / 255.0f, 15 / 255.0f, 1.0f);
	SetShaderMaterial("glass");
	m_basicMeshes->DrawCylinderMesh();


	/************************ Red candle cap ***************************************/
	scaleXYZ = glm::vec3(1.1, 0.3f, 1.1);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-2.3f, 1.702f, 2.0f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderColor(136 / 255.0f, 137 / 255.0f, 112 / 255.0f, 1.0f);
	SetShaderMaterial("glass");
	m_basicMeshes->DrawCylinderMesh();
}

void SceneManager::RenderTable()
{
	auto scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f);
	auto XrotationDegrees = 0.0f;
	auto YrotationDegrees = 0.0f;
	auto ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	auto positionXYZ = glm::vec3(2.0f, -0.5f, 1.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);
	
	SetTextureUVScale(2.0f, 2.0f);
	SetShaderTexture("oak");
	SetShaderMaterial("wood");
	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();

	// Back left table leg
	scaleXYZ = glm::vec3(1.0f, 10.0f, 1.0f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-7.5f, -6.0f, -3.5f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("oak");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("wood");
	m_basicMeshes->DrawBoxMesh();

	// Back right table leg
	scaleXYZ = glm::vec3(1.0f, 10.0f, 1.0f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(11.5f, -6.0f, -3.5f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("oak");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("wood");
	m_basicMeshes->DrawBoxMesh();

	// Front left table leg
	scaleXYZ = glm::vec3(1.0f, 10.0f, 1.0f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(-7.5f, -6.0f, 5.5f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("oak");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("wood");
	m_basicMeshes->DrawBoxMesh();

	// Front right table leg
	scaleXYZ = glm::vec3(1.0f, 10.0f, 1.0f);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(11.5f, -6.0f, 5.5f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("oak");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("wood");
	m_basicMeshes->DrawBoxMesh();


}

void SceneManager::RenderPingPongBall()
{
	/************************ Ping-pong ball ***************************/
	auto scaleXYZ = glm::vec3(0.5f, 0.5f, 0.5f);
	auto XrotationDegrees = 0.0f;
	auto YrotationDegrees = 0.0f;
	auto ZrotationDegrees = 0.0f;
	auto positionXYZ = glm::vec3(3.2f, 0.5f, 2.7f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderColor(45.0f / 255, 213.0f / 255, 245.0f / 255, 1);
	SetShaderMaterial("plastic");
	m_basicMeshes->DrawSphereMesh();

}

void SceneManager::RenderFloor()
{
	/*********************** Bottom world plane*****************************/
	auto scaleXYZ = glm::vec3(60.0f, 1.0f, 60.0f);
	auto XrotationDegrees = 0.0f;
	auto YrotationDegrees = 0.0f;
	auto ZrotationDegrees = 0.0f;
	auto positionXYZ = glm::vec3(0.0f, -11.01, 0.0f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("concrete");
	SetShaderMaterial("brick");
	m_basicMeshes->DrawPlaneMesh();

}

void SceneManager::RenderCeiling()
{
	/*********************** Top world plane *****************************/
	auto scaleXYZ = glm::vec3(60.0f, 1.0f, 60.0f);
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	auto positionXYZ = glm::vec3(0.0f, 40.0f, 0.0f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("ceiling-tile");
	// Make tiles smaller
	SetTextureUVScale(3.0f, 3.0f);
	SetShaderMaterial("brick");
	m_basicMeshes->DrawPlaneMesh();
}

void SceneManager::RenderWalls()
{
	\
	/************************ Front world plane **************************/
	auto scaleXYZ = glm::vec3(60.0f, 1.0f, 60.0f);
	auto XrotationDegrees = 90.0f;
	auto YrotationDegrees = 0.0f;
	auto ZrotationDegrees = 0.0f;
	auto positionXYZ = glm::vec3(0.0f, 0.0f, 60.0f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("brick");
	// Make bricks smaller
	SetTextureUVScale(5.0f, 5.0f);
	SetShaderMaterial("brick");
	m_basicMeshes->DrawPlaneMesh();

	/************************ Back world plane ***************************/
	scaleXYZ = glm::vec3(60.0f, 1.0f, 60.0f);
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(0.0f, 0.0f, -60.0f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("brick");
	SetShaderMaterial("brick");
	m_basicMeshes->DrawPlaneMesh();

	/************************ Left world plane ****************************/
	scaleXYZ = glm::vec3(60.0f, 1.0f, 60.0f);
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 90.0f;
	positionXYZ = glm::vec3(-60.0f, 0.0f, 0.0f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("brick");
	SetShaderMaterial("brick");
	m_basicMeshes->DrawPlaneMesh();

	/************************ Right world plane ***************************/
	scaleXYZ = glm::vec3(60.0f, 1.0f, 60.0f);
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 90.0f;
	positionXYZ = glm::vec3(60.0f, 0.0f, 0.0f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("brick");
	SetShaderMaterial("brick");
	m_basicMeshes->DrawPlaneMesh();
}

void SceneManager::RenderChickenBroth()
{
	/*********************** Chicken Broth ******************************/
	auto scaleXYZ = glm::vec3(2.0f, 4.0f, 1.0f);
	auto XrotationDegrees = 0.0f;
	auto YrotationDegrees = -8.0f;
	auto ZrotationDegrees = 0.0f;
	auto positionXYZ = glm::vec3(4.0f, 2.001f, 0.1f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderColor(167 / 255.0f, 193 / 255.0f, 132 / 255.0f, 1.0f);
	SetShaderMaterial("plastic");
	m_basicMeshes->DrawBoxMesh();

	/************************ Chicken Broth Cap **********************************/
	scaleXYZ = glm::vec3(0.25, 0.3f, 0.25);
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	positionXYZ = glm::vec3(4.6f, 4.002f, 0.0f);

	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderTexture("bottle-cap");
	SetShaderMaterial("plastic");
	m_basicMeshes->DrawCylinderMesh();
}

void SceneManager::RenderPastaBox()
{
	/*********************** Fettuccine Box ************************/
	auto scaleXYZ = glm::vec3(5.5f, 1.2f, 1.0f);
	auto XrotationDegrees = 0.0f;
	auto YrotationDegrees = -30.0f;
	auto ZrotationDegrees = 0.0f;
	auto positionXYZ = glm::vec3(4.0f, 0.601f, 2.0f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderColor(67.0f / 255, 88.0f / 255, 133.0f / 255, 1);
	m_basicMeshes->DrawBoxMesh();
}

void SceneManager::RenderMakeup()
{
	/************************ Makeup cylinder ***************************/
	auto scaleXYZ = glm::vec3(0.8f, 0.3f, 0.8f);
	auto XrotationDegrees = 0.0f;
	auto YrotationDegrees = 0.0f;
	auto ZrotationDegrees = 0.0f;
	auto positionXYZ = glm::vec3(1.8f, 0.001f, 2.5f);
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
	SetShaderColor(140.0f / 255, 115.0f / 255, 118.0f / 255, 1);
	m_basicMeshes->DrawCylinderMesh();
}

void SceneManager::RenderWorldBorders()
{
	RenderFloor();
	RenderCeiling();
	RenderWalls();
}